Blackwood Seven  
12/15/2016  










# KPI
## Total **transactions** – 2014 till 2016 YTD

![](report_files/figure-html/KPI1-1.png)<!-- -->


# Media investment
## Media investment - 2015 till 2016 YTD 

![](report_files/figure-html/MediaInvestment-1.png)<!-- -->

[comment]: <> (## Media Investment Table )



# Top competitors

## Top competitor activities 

![](report_files/figure-html/competitors-1.png)<!-- -->




# Decomposition



## Total decomposition





![](report_files/figure-html/decplots4-1.png)<!-- -->


## Decomposition per year


![](report_files/figure-html/decplots3-1.png)<!-- -->


## Weekly decomposition

![](report_files/figure-html/decplots5-1.png)<!-- -->




# Model fitting

## Model fitting 

![](report_files/figure-html/Modelfitting-1.png)<!-- -->



# Budget Allocation

## Budget allocation 








![](report_files/figure-html/Budget2-1.png)<!-- -->

## Digital Budget Allocation 

![](report_files/figure-html/Budget3-1.png)<!-- -->


## Offline Budget Allocation 



![](report_files/figure-html/Budget4-1.png)<!-- -->



# Media Mix






## Total Media ROI  


![](report_files/figure-html/ROIplots0, -1.png)<!-- -->




## Digital ROI  


![](report_files/figure-html/ROIplots00, -1.png)<!-- -->


## Digital Search & WebTV ROI  


![](report_files/figure-html/ROIplots1, -1.png)<!-- -->

## Offline Media ROI  


![](report_files/figure-html/ROIplots2, -1.png)<!-- -->



# Tactical Media Learnings
## Tactical Media Learnings

![](report_files/figure-html/TacticalMedia, -1.png)<!-- -->



# Uncertainty ranges
## ROI distributions






![](report_files/figure-html/distr2-1.png)<!-- -->

